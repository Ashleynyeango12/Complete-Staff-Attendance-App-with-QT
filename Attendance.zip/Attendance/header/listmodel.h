#ifndef LISTMODEL_H
#define LISTMODEL_H

#include <QObject>
#include <QSqlQueryModel>
#include <QBuffer>

class ListModel : public QSqlQueryModel
{
    Q_OBJECT
public:
    /* 
     *
     * We list all the roles to be used in TableView.
     * They must be in memory above the Qt::UserRole parameter.
     * Since the information under this address is not for customizations
     * */
    enum Roles {
        IdRole = Qt::UserRole + 1,      // id
        NameRole,                      // original_title
        DepartmentRole,                      // release_date
        PhoneRole,                         // tagline
        Job_positionRole                              // vote_average
                               //image
    };



    explicit ListModel(QObject *parent = 0);



   
    // Make it impossible to return data
    QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const;


protected:
    /*
     * 
     *
     * The method used in the wilds of the QAbstractItemModel base class,
     * Inheriting the QSqlQueryModel class
     * */
    QHash<int, QByteArray> roleNames() const;

signals:


public slots:
    void updateModel();
    void updateData();
    int getId(int row);
    QString getName(int row);
    QString getDepartment(int row);
    QString getPhone(int row);
    QString getJob_position(int row);
    



};






#endif // LISTMODEL_H
