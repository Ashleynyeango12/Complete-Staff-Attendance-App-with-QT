#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "header\database.h"
#include "header\listmodel.h"
#include "header\atten.h"
#include <QQmlContext>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QQmlApplicationEngine engine;


    DataBase database;


    ListModel *model = new ListModel();

    AttendModel  *modus = new AttendModel();

    engine.rootContext()->setContextProperty("myModel", model);
    engine.rootContext()->setContextProperty("attendModel", modus);
    engine.rootContext()->setContextProperty("database", &database);
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

    return app.exec();
}

