#include "header\listmodel.h"
#include <QLabel>
#include <QSqlRecord>
#include <header\database.h>

ListModel::ListModel(QObject *parent) :
    QSqlQueryModel(parent)
{
    this->updateModel();

}


// Method of obtaining data from the model
QVariant ListModel::data(const QModelIndex & index, int role) const {

    
    // Define column number by number role
    int columnId = role - Qt::UserRole - 1;
//    qDebug()<<"User Role"<< Qt::UserRole;
//    qDebug()<<"Column Id:"<< columnId;
//    qDebug()<<"Role:"<< role;


   
    // Creating array using column id
    QModelIndex modelIndex = this->index(index.row(), columnId);
//    qDebug()<<"Index:"<< index;

    return QSqlQueryModel::data(modelIndex, Qt::DisplayRole);
}



QHash<int, QByteArray> ListModel::roleNames() const  {

    QHash<int, QByteArray> roles;
      roles[IdRole] = "id";
      roles[NameRole] = "name";
      roles[DepartmentRole] = "dep";
      roles[PhoneRole] = "phone";
      roles[Job_positionRole] = "job";
      return roles;
}

//The method updates the tables in the data model representation
void ListModel::updateModel()
{
    
   
     this->setQuery("SELECT id, " TABLE_NAME ", " TABLE_DEPARTMENT ", " TABLE_PHONE" , " TABLE_JOB_POSITION" FROM " TABLE);


}

void ListModel::updateData()
{
     
}

// Getting the id of the row in the data view model
int ListModel::getId(int row)
{
    return this->data(this->index(row, 0), IdRole).toInt();
}


//Printing data based on selected Id value


QString ListModel::getName(int row)
{
    return this->data(this->index(row, 0), NameRole).toString();
}

QString ListModel::getDepartment(int row)
{
   return this->data(this->index(row, 0), DepartmentRole).toString();
}


QString ListModel::getPhone(int row)
{
    return this->data(this->index(row, 0), PhoneRole).toString();
}

QString ListModel::getJob_position(int row)
{
    return this->data(this->index(row, 0), Job_positionRole).toString();
}





















