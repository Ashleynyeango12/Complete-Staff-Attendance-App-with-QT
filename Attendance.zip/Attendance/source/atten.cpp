#include "header\atten.h"
#include <QLabel>
#include <QSqlRecord>
#include <header\database.h>

AttendModel::AttendModel(QObject *parent) :
    QSqlQueryModel(parent)
{
    this->updateModel();

}

// Modelden veri elde etme yöntemi
// Method of obtaining data from the model
QVariant AttendModel::data(const QModelIndex & index, int role) const {

    // Sayı rolüne göre sütun numarasını tanımlayın
    // Define column number by number role
    int columnId = role - Qt::UserRole - 1;
//    qDebug()<<"User Role"<< Qt::UserRole;
//    qDebug()<<"Column Id:"<< columnId;
//    qDebug()<<"Role:"<< role;


    // Column id kullanarak dizi oluşturma
    // Creating array using column id
    QModelIndex modelIndex = this->index(index.row(), columnId);
//    qDebug()<<"Index:"<< index;

    return QSqlQueryModel::data(modelIndex, Qt::DisplayRole);
}



QHash<int, QByteArray> AttendModel::roleNames() const  {

    QHash<int, QByteArray> roles;
      roles[IdRole] = "id";
      roles[NameRole] = "name";
      roles[StartRole] = "start";
      roles[EndRole] = "end";
      roles[DateRole] = "date";
      return roles;
}

// Yöntem, veri modeli gösterimindeki tabloları günceller
//The method updates the tables in the data model representation
void AttendModel::updateModel()
{


     this->setQuery("select * from Attendance");


}

void AttendModel::updateData()
{

}
// Veri görünümü modelinde satırın kimliğini alma
// Getting the id of the row in the data view model
int AttendModel::getId(int row)
{
    return this->data(this->index(row, 0), IdRole).toInt();
}

//Seçilen Id değerine göre verileri yazdırma
//Printing data based on selected Id value


QString AttendModel::getName(int row)
{
    return this->data(this->index(row, 0), NameRole).toString();
}

QString AttendModel::getStart(int row)
{
   return this->data(this->index(row, 0), StartRole).toString();
}


QString AttendModel::getEnd(int row)
{
    return this->data(this->index(row, 0), EndRole).toString();
}

QString AttendModel::getDate(int row)
{
    return this->data(this->index(row, 0), DateRole).toString();
}






















