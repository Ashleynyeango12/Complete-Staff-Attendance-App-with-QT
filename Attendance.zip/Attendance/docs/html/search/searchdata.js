var indexSectionsWithContent =
{
  0: "adlu",
  1: "adl",
  2: "u"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Pages"
};

